export const MODULE_ID = "grand-design-ai";
export const ACTOR_FLAG = "conversion";
export const REGISTRY_FLAG = "registry";
export const TEST_SCENARIO_FLAG = "testScenario";
export const GROWTH_EVENTS_FLAG = "growthEvents";
export const GROWTH_PROPOSALS_FLAG = "growthProposals";
export const LEVEL_PROGRESSION_FLAG = "levelProgression";

export const POWER_TIERS = new Set(["standard", "elevated", "prestige"]);
export const SKILL_TIERS = new Set([1, 2, 3]);
export const LINEAGE_OPERATIONS = new Set(["origin", "combine", "upgrade"]);
// Grand Design's own vocabulary for "what kind of mechanical entry is this" -- deliberately
// generic (not tied to any one TTRPG's Item schema) so the same set works for every supported
// game system's adapter. Kept as PF2E_ITEM_KINDS as well for backward compatibility with any
// external code/flags referencing the old name; both point at the same Set.
export const GRAND_DESIGN_ITEM_KINDS = new Set(["feat", "action", "reaction", "free", "passive", "spell", "weapon"]);
export const PF2E_ITEM_KINDS = GRAND_DESIGN_ITEM_KINDS;
// Spell "school" is a real enum-constrained field in some systems (e.g. dnd5e's abj/con/div/
// enc/evo/ill/nec/trs) even though it isn't meaningfully used by others (PF2e uses freeform
// "tradition" instead). Validated the same way regardless of active system so the AI-facing
// schema and validator stay system-agnostic; each system adapter reads whichever field it needs.
export const SPELL_SCHOOLS = new Set(["abj", "con", "div", "enc", "evo", "ill", "nec", "trs"]);
export const FREQUENCY_PERIODS = new Set(["round", "minute", "hour", "day", "encounter", "unlimited"]);
export const GRAND_DESIGN_MAX_LEVEL = 100;
export const CLASS_EVOLUTION_LEVELS = new Set([20, 30, 50]);
export const SUPPORTED_GAME_SYSTEMS = new Set(["pf2e", "dnd5e"]);
