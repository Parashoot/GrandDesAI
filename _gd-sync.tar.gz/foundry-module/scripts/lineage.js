import { LINEAGE_OPERATIONS } from "./constants.js";
import { createMechanicsHtml } from "./mechanics.js";
import { getSystemAdapter } from "./systems/index.js";

export function emptyRegistry() {
  return { version: 1, classes: {}, skills: {} };
}

export function normalizeEntry(kind, entry, registry, operation = "origin") {
  const bucket = kind === "class" ? registry.classes : registry.skills;
  const metadata = entry.metadata ?? {};
  const lineage = metadata.lineage ?? {};
  const requestedOperation = lineage.operation ?? operation;
  const sourceIds = uniqueStrings(lineage.sources ?? []);
  const id = metadata.id ?? `${kind}:${slugify(entry.name)}`;

  if (!LINEAGE_OPERATIONS.has(requestedOperation)) {
    throw new Error(`Unsupported lineage operation: ${requestedOperation}.`);
  }
  if (requestedOperation === "combine" && sourceIds.length < 2) {
    throw new Error("A combined entry must reference at least two approved source entries.");
  }
  if (requestedOperation === "upgrade" && sourceIds.length !== 1) {
    throw new Error("An upgraded entry must reference exactly one approved source entry.");
  }
  for (const sourceId of sourceIds) {
    if (!bucket[sourceId]) {
      throw new Error(`Lineage source ${sourceId} is not an approved ${kind}.`);
    }
  }

  const inheritedTags = sourceIds.flatMap((sourceId) => bucket[sourceId].metadata.tags);
  return {
    ...entry,
    metadata: {
      id,
      tags: uniqueStrings([...(metadata.tags ?? []), ...inheritedTags]),
      lineage: {
        operation: requestedOperation,
        sources: sourceIds,
        rationale: stringOrEmpty(lineage.rationale)
      }
    }
  };
}

export function registerEntry(kind, entry, itemId, registry) {
  const bucketName = kind === "class" ? "classes" : "skills";
  const next = cloneRegistry(registry);
  next[bucketName][entry.metadata.id] = {
    name: entry.name,
    itemId,
    approvedAt: new Date().toISOString(),
    metadata: entry.metadata,
    gameItem: entry.gameItem,
    mechanics: entry.mechanics
  };
  return next;
}

/**
 * Builds the {type, system, flags} payload for actor.createEmbeddedDocuments("Item", [...]),
 * plus an optional async postCreate(item) step, for whichever game system is currently active.
 * The title/description/flags assembled here (name, PF2e-or-not "system equivalent" line,
 * mechanics HTML, tags, lineage) are entirely system-agnostic; only the actual system.* shape
 * (and, for dnd5e, the follow-up Activity) comes from the active system's adapter.
 */
export function createFeatureSource(kind, entry, systemId) {
  const adapter = getSystemAdapter(systemId);
  const title = kind === "class" ? `[${entry.name}] Class` : `[${entry.name}] Skill`;
  const equivalent = adapter.equivalentLabel(kind, entry);
  const tags = entry.metadata.tags.length ? entry.metadata.tags.join(", ") : "none";
  const sources = entry.metadata.lineage.sources.length
    ? entry.metadata.lineage.sources.join(", ")
    : "none";
  const { source: systemSource, postCreate } = adapter.buildItemSource(kind, entry);
  const source = {
    name: title,
    type: systemSource.type,
    system: {
      ...systemSource.system,
      description: {
        ...(systemSource.system?.description ?? {}),
        value: `<p><strong>${escapeHtml(adapter.label)} equivalent:</strong> ${escapeHtml(equivalent)}</p>${createMechanicsHtml(entry)}<p><strong>Tags:</strong> ${escapeHtml(tags)}</p><p><strong>Lineage:</strong> ${escapeHtml(entry.metadata.lineage.operation)}; sources: ${escapeHtml(sources)}</p><p>${escapeHtml(entry.metadata.lineage.rationale)}</p>`
      }
    },
    flags: {
      "grand-design-ai": {
        registryId: entry.metadata.id,
        kind,
        metadata: entry.metadata
      }
    }
  };
  return { source, postCreate };
}

export function cloneRegistry(registry) {
  return structuredClone(registry ?? emptyRegistry());
}

export function uniqueStrings(values) {
  return [...new Set(values.filter((value) => typeof value === "string" && value.trim()).map((value) => value.trim()))];
}

function slugify(value) {
  return String(value)
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "") || "unnamed";
}

function stringOrEmpty(value) {
  return typeof value === "string" ? value.trim() : "";
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
