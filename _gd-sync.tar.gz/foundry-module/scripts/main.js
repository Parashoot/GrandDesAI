import { GrandDesignApi } from "./api.js";
import { defaultAtlasAssetPath, isLegacyGithubAtlasPath } from "./atlas.js";
import { MODULE_ID } from "./constants.js";
import { openGrowthManager } from "./growth-ui.js";
import { createConfiguredAiAdapter, registerAiProviderSettings } from "./ai-provider-config.js";
import { isSupportedSystem, supportedSystemIds } from "./systems/index.js";

Hooks.once("init", () => {
  registerAiProviderSettings();
  game.settings.register(MODULE_ID, "atlasAssetPath", {
    name: "Grand Design Atlas Asset",
    hint: "Path to a licensed world-map image or SVG to use as the Foundry scene background.",
    scope: "world",
    config: true,
    type: String,
    default: defaultAtlasAssetPath()
  });
  game.settings.register(MODULE_ID, "runTestScenarioOnLaunch", {
    name: "Run Test Campaign on Launch",
    hint: "GM only. Automatically runs 'The First Steam' test campaign every time this world finishes loading. Intended for development machines, not live play.",
    scope: "world",
    config: true,
    type: Boolean,
    default: false
  });
  game.modules.get(MODULE_ID).api = new GrandDesignApi();
});

Hooks.once("ready", async () => {
  const atlasAssetPath = game.settings.get(MODULE_ID, "atlasAssetPath");
  if (game.user.isGM && isLegacyGithubAtlasPath(atlasAssetPath)) {
    await game.settings.set(MODULE_ID, "atlasAssetPath", defaultAtlasAssetPath());
    ui.notifications.info("Grand Design AI migrated the atlas setting to Foundry's local module asset.");
  }
  if (!isSupportedSystem(game.system.id)) {
    ui.notifications.warn(
      `Grand Design AI is loaded outside a supported game system (supported: ${supportedSystemIds().join(", ")}); actor sync is disabled.`
    );
  }
  if (game.user.isGM) {
    try {
      const adapter = createConfiguredAiAdapter();
      if (adapter) game.modules.get(MODULE_ID).api.setProposalAdapter(adapter);
    } catch (error) {
      console.warn(`${MODULE_ID} | AI provider is not configured`, error);
    }
  }
  if (game.user.isGM && game.settings.get(MODULE_ID, "runTestScenarioOnLaunch")) {
    if (game.system.id !== "pf2e") {
      ui.notifications.warn("Grand Design AI cannot auto-run the test campaign outside the PF2e system.");
    } else {
      try {
        await game.modules.get(MODULE_ID).api.runTestScenario();
      } catch (error) {
        console.error(`${MODULE_ID} | automatic test campaign run failed`, error);
        ui.notifications.error("Grand Design AI's automatic test campaign run failed. See console for details.");
      }
    }
  }
});

Hooks.on("getActorSheetHeaderButtons", (sheet, buttons) => {
  if (!game.user.isGM || !isSupportedSystem(game.system.id) || !sheet.actor) {
    return;
  }
  buttons.unshift({
    class: "grand-design-import",
    icon: "fas fa-sparkles",
    label: "Grand Design",
    onclick: () => openImporter(sheet.actor)
  });
  buttons.unshift({
    class: "grand-design-growth",
    icon: "fas fa-seedling",
    label: "Growth",
    onclick: () => openGrowthManager(sheet.actor)
  });
});

function openImporter(actor) {
  new Dialog({
    title: "Apply Grand Design Conversion",
    content: `<form class="grand-design-conversion"><div class="form-group stacked"><label>Conversion JSON</label><textarea name="conversion" rows="16" placeholder='{"character":"Name","classes":[...],"skills":[...]}'></textarea></div></form>`,
    buttons: {
      apply: {
        icon: '<i class="fas fa-check"></i>',
        label: "Validate and Apply",
        callback: async (html) => {
          const source = html.find('textarea[name="conversion"]').val();
          let payload;
          try {
            payload = JSON.parse(source);
          } catch {
            ui.notifications.error("The conversion input is not valid JSON.");
            return;
          }
          const api = game.modules.get(MODULE_ID).api;
          const validation = api.validate(payload);
          if (!validation.valid) {
            ui.notifications.error(validation.errors.join(" "));
            return;
          }
          try {
            await api.applyToActor(actor, payload);
            ui.notifications.info(`Applied Grand Design conversion to ${actor.name}.`);
          } catch (error) {
            console.error(`${MODULE_ID} | conversion import failed`, error);
            ui.notifications.error(error.message);
          }
        }
      },
      cancel: {
        icon: '<i class="fas fa-times"></i>',
        label: "Cancel"
      }
    },
    default: "apply"
  }).render(true);
}
