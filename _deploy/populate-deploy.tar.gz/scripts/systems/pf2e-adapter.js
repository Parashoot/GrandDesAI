// PF2e-specific translation from a Grand Design entry (system-agnostic: name, tier/level,
// gameItem.kind, mechanics) into a real PF2e Foundry Item. This is the original
// createFeatureSource() logic, unchanged in behavior, extracted here so it lives alongside its
// dnd5e counterpart behind the shared systems/index.js dispatch instead of being the only path.

export const SYSTEM_ID = "pf2e";
export const SYSTEM_LABEL = "Pathfinder Second Edition";

export function buildItemSourcePf2e(kind, entry) {
  const type = itemTypeFor(entry.gameItem.kind);
  const level = kind === "class" ? Math.min(20, Math.max(1, entry.level)) : entry.tier;
  const category = kind === "class" ? "classfeature" : "skill";
  const system = {};

  if (type === "feat") {
    system.category = entry.gameItem.kind === "passive" && kind !== "class" ? "skill" : category;
    system.level = { value: level };
  } else if (type === "action") {
    system.actionType = { value: pf2eActionType(entry.gameItem.kind) };
    system.actions = { value: entry.mechanics.actions ?? null };
    system.category = "offensive";
  } else if (type === "spell") {
    system.level = { value: entry.gameItem.rank };
    system.traits = { traditions: { value: [entry.gameItem.tradition] }, value: [] };
    system.time = { value: `${entry.mechanics.actions ?? 1} action${entry.mechanics.actions === 1 ? "" : "s"}` };
    system.duration = { value: entry.mechanics.duration, sustained: false };
  } else if (type === "weapon") {
    const weaponDamage = parseWeaponDamage(entry.gameItem.damage);
    system.category = entry.gameItem.category ?? "simple";
    system.group = entry.gameItem.group ?? "club";
    system.damage = { dice: weaponDamage.dice, die: weaponDamage.die, damageType: entry.gameItem.damageType };
    system.traits = { value: entry.gameItem.traits ?? [] };
  }

  // Nothing more to do after the embedded Item exists -- PF2e models everything through flat
  // system.* fields set above, with no equivalent of dnd5e's separate "Activity" documents.
  return { source: { type, system }, postCreate: null };
}

export function getCharacterLevelPf2e(actor) {
  return actor.system?.details?.level?.value ?? null;
}

export function equivalentLabelPf2e(kind, entry) {
  return kind === "class" ? entry.system_chassis ?? "Pending PF2e chassis review" : entry.system_equivalent;
}

function itemTypeFor(kind) {
  if (kind === "reaction" || kind === "free") return "action";
  if (kind === "passive") return "feat";
  return kind;
}

function pf2eActionType(kind) {
  if (kind === "reaction") return "reaction";
  if (kind === "free") return "free";
  return "action";
}

function parseWeaponDamage(formula) {
  const match = /^(\d+)d(\d+)/i.exec(formula);
  return { dice: Number(match[1]), die: `d${match[2]}` };
}

// --- Populate: NPC/monster/item spawning -------------------------------------------------------
// Best-effort PF2e translation of a populate.js spec, following PF2e's well-documented actor/item
// schema conventions (unlike dnd5e-adapter.js's live-verified fields, this hasn't been checked
// against a running PF2e world in this session -- every spawned Actor/Item remains fully
// GM-editable afterward, same as the rest of Grand Design's PF2e support).

const ABILITY_KEYS_PF2E = ["str", "dex", "con", "int", "wis", "cha"];

function abilityModPf2e(score) {
  return Math.floor(((score ?? 10) - 10) / 2);
}

export function buildNpcActorSourcePf2e(spec) {
  const isMonster = spec.actorKind === "monster";
  const abilities = spec.abilities ?? {};
  const system = {
    abilities: Object.fromEntries(ABILITY_KEYS_PF2E.map((key) => [key, { mod: abilityModPf2e(abilities[key]) }])),
    attributes: {
      hp: { value: spec.hp, max: spec.hp },
      ac: { value: spec.ac },
      speed: { value: spec.speed ?? 25 }
    },
    details: {
      level: { value: isMonster ? Math.round(spec.cr ?? 1) : (spec.level ?? 1) },
      biography: { value: spec.bio ?? "", public: spec.bio ?? "" }
    },
    traits: { size: { value: isMonster ? (spec.size ?? "med") : "med" }, value: [] }
  };
  const source = { name: spec.name, type: "npc", system };

  const embeddedItems = [];
  if (!isMonster && spec.weaponSpec) embeddedItems.push(buildWeaponItemDataPf2e(spec.weaponSpec));
  if (isMonster && spec.attack) embeddedItems.push(buildNaturalAttackItemDataPf2e(spec.attack));
  return { source, embeddedItems };
}

export function buildEquipmentItemSourcePf2e(spec) {
  return { source: buildWeaponItemDataPf2e(spec), postCreate: null };
}

function buildWeaponItemDataPf2e(weaponSpec) {
  const damage = parseWeaponDamage(weaponSpec.damage);
  const system = {
    category: weaponSpec.category ?? "simple",
    group: weaponSpec.group ?? "club",
    damage: { dice: damage.dice, die: damage.die, damageType: weaponSpec.damageType },
    traits: { value: weaponSpec.traits ?? [] },
    runes: { potency: Number.isInteger(weaponSpec.bonus) ? weaponSpec.bonus : 0 }
  };
  return { name: weaponSpec.name, type: "weapon", system };
}

function buildNaturalAttackItemDataPf2e(attack) {
  const damage = parseWeaponDamage(attack.damage);
  const system = {
    category: "unarmed",
    group: "brawling",
    damage: { dice: damage.dice, die: damage.die, damageType: attack.damageType },
    traits: { value: ["unarmed", "agile", "finesse"] }
  };
  return { name: attack.name, type: "weapon", system };
}
