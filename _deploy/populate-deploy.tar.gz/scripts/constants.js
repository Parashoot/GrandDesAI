export const MODULE_ID = "grand-design-ai";
export const ACTOR_FLAG = "conversion";
export const REGISTRY_FLAG = "registry";
export const TEST_SCENARIO_FLAG = "testScenario";
export const GROWTH_EVENTS_FLAG = "growthEvents";
export const GROWTH_PROPOSALS_FLAG = "growthProposals";
export const LEVEL_PROGRESSION_FLAG = "levelProgression";

export const POWER_TIERS = new Set(["standard", "elevated", "prestige"]);
export const SKILL_TIERS = new Set([1, 2, 3]);
export const LINEAGE_OPERATIONS = new Set(["origin", "combine", "upgrade"]);
// Grand Design's own vocabulary for "what kind of mechanical entry is this" -- deliberately
// generic (not tied to any one TTRPG's Item schema) so the same set works for every supported
// game system's adapter. Kept as PF2E_ITEM_KINDS as well for backward compatibility with any
// external code/flags referencing the old name; both point at the same Set.
export const GRAND_DESIGN_ITEM_KINDS = new Set(["feat", "action", "reaction", "free", "passive", "spell", "weapon"]);
export const PF2E_ITEM_KINDS = GRAND_DESIGN_ITEM_KINDS;
// Spell "school" is a real enum-constrained field in some systems (e.g. dnd5e's abj/con/div/
// enc/evo/ill/nec/trs) even though it isn't meaningfully used by others (PF2e uses freeform
// "tradition" instead). Validated the same way regardless of active system so the AI-facing
// schema and validator stay system-agnostic; each system adapter reads whichever field it needs.
export const SPELL_SCHOOLS = new Set(["abj", "con", "div", "enc", "evo", "ill", "nec", "trs"]);
export const FREQUENCY_PERIODS = new Set(["round", "minute", "hour", "day", "encounter", "unlimited"]);
// A growth event's outcome and how much "evidence weight" it contributes -- both toward Grand
// Design progress points and toward the weighted-evidence threshold a proposal template needs.
// Genuine effort is evidence even without success: a character who tries and fails at the same
// kind of thing over and over is still practicing it, so failure/criticalFailure are valid
// outcomes, not rejected ones -- they're simply worth less than success/criticalSuccess, so a
// handful of successes still gets there far faster than a pile of failures, but enough failures
// (persistence) can still add up to real growth on their own. criticalFailure is weighted above
// plain failure on purpose: a dramatic, costly failure (getting hurt, a plan backfiring badly)
// tends to teach something concrete -- caution, a scar, a reflex -- even though the roll itself
// didn't succeed, which is exactly the kind of lesson an AI proposal is free to shape a defensive
// or resistance-flavored entry around instead of a mastery-flavored one.
export const GROWTH_EVENT_OUTCOME_WEIGHTS = {
  criticalSuccess: 1.6,
  success: 1,
  criticalFailure: 0.5,
  failure: 0.25
};
export const GRAND_DESIGN_MAX_LEVEL = 100;
export const CLASS_EVOLUTION_LEVELS = new Set([20, 30, 50]);
export const SUPPORTED_GAME_SYSTEMS = new Set(["pf2e", "dnd5e"]);
// Most Class/Skill entries are "standard". A "red" entry is a genuinely taboo, vile, or forced
// origin (see vice-taxonomy.js) -- still a real, potentially powerful entry, but one that must
// carry an explicit metadata.malignance {vice, drawback} rather than reading as an ordinary
// heroic ability. Ordinary morally-gray professions (thief, assassin, spy) are NOT red; only
// entries built from genuine vice or violation are.
export const ENTRY_POLARITIES = new Set(["standard", "red"]);
// Natural-language "Populate" spawn requests (scripts/populate.js) produce one of these document
// kinds. "npc" and "monster" both create a real Actor; the split exists only so the local
// heuristic and any registered AI adapter know which template bank/spec shape to use --
// mechanically an NPC and a monster are both just Foundry Actors of type "npc".
export const SPAWN_DOCUMENT_KINDS = new Set(["npc", "monster", "item"]);
